from .Camera import *
from .Project import *
from .Recognizer import *
import requests
import datetime
import json

# from db import db

# import mysql.connector
import cv2 as cv



# def initiate():
#     project = Project()
#     project.

# def test(c=1):
#     cam = Camera(c)
#     cam.test_Cam()

def startUp():
    try:
        cam = Camera(1)
        frame = cam.getFrame()
        if frame == []:
            raise Exception
    except:
        cam = Camera(0)
    rec = Recognizer()

    return cam, rec



def standBy(camera, recognizer):
    window = Project()
    prev_label = ''
    count = 0
    while True:
        frame = camera.getFrame()
        # print(frame)
        # cv.imshow("frame", frame)
        faces, frame_roi = recognizer.cropToFace(frame)
        # print(faces)

        # for face in faces:
        #     cv.imshow("faces", face)


        if len(faces) > 0:
            # print(len(faces))

            for face in frame_roi:
                # print(face)
                camera.mark(frame, face[0] , face[1], face[2] ,face[3])
                # if label == prev_label:
                #     count += 1
                #     if count >= 3:
                #         mark_attendance(label)
                #         count = 0
                # else:
                #     count = 0
                # prev_label = label
            # else:
            #     camera.mark(frame, prev_label, recognizer.x,recognizer.y,recognizer.w,recognizer.h)

        window.dashboard(frame)
        if cv.waitKey(20) == ord("e"):
            break
        

def boot():
    
    cam, rec = startUp()
    standBy(camera= cam, recognizer= rec)

    

def mark_attendance(images):
    pass
